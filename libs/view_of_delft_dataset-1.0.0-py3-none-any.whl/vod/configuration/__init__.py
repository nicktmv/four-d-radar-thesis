from .file_locations import KittiLocations
from .file_locations import VodTrackLocations
